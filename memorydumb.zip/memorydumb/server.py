import socketserver
import time
import hmac
import re

HOST = "0.0.0.0"
PORT = 5050

# === ASCII LOGO (HexDefender) ===
BANNER = r"""
 _   _           ____       __               _           
| | | | _____  _|  _ \ ___ / _| ___ _ __   __| | ___ _ __ 
| |_| |/ _ \ \/ / | | / _ \ |_ / _ \ '_ \ / _` |/ _ \ '__|
|  _  |  __/>  <| |_| |  __/  _|  __/ | | | (_| |  __/ |   
|_| |_|\___/_/\_\____/ \___|_|  \___|_| |_|\__,_|\___|_|   

                 HEXDEFENDER QUIZ SERVICE
"""

# === Questions: exact answers required (copy/paste). ===
QUESTIONS = [
    ("Q1) What is the system NTBuildLab value?", "7601.17514.amd64fre.win7sp1_rtm."),
    ("Q2) Is the system 64-bit? (Copy the value exactly)", "True"),
    ("Q3) What is the NtSystemRoot value?", r"C:\Windows"),
    ("Q4) What is the name of the memory dump tool process?", "DumpIt.exe"),
    ("Q5) What is the Console Host process name?", "conhost.exe"),
    ("Q6) What is the non-default program open in Session 2?", "StikyNot.exe"),
    ("Q7) What is the username associated with StikyNot.exe?", "2pac/SlimShady"),
    ("Q8) What is the answer from UserAssist for the required entry?", "NOTEPAD.EXE"),
    ("Q9) What is the PID of DumpIt.exe?", "2624"),
    ("Q10) What is the full command line of DumpIt.exe (including quotes)?",
     r"\"C:\Users\eminem\Desktop\DumpIt\DumpIt.exe\""),
]

# Flag printed only after all answers are correct
FLAG = "HexDefender{MEMLAB_Ch@lleng_QU!Z_C0MPL3T3}"

# === Security / Hardening ===
MAX_LINE = 300  # prevents huge payloads
READ_TIMEOUT = 60  # seconds per question
TOTAL_TIMEOUT = 30 * 60  # max session time
ALLOWED_INPUT = re.compile(r"^[\x20-\x7E]+$")  # printable ASCII (space to ~)

def normalize_answer(s: str) -> str:
    # Remove only line terminators to keep copy/paste strict
    return s.rstrip("\r\n")

def safe_equal(a: str, b: str) -> bool:
    return hmac.compare_digest(a, b)

class QuizHandler(socketserver.BaseRequestHandler):
    def send(self, msg: str) -> None:
        self.request.sendall(msg.encode("utf-8", errors="replace"))

    def recvline(self) -> str:
        self.request.settimeout(READ_TIMEOUT)
        data = b""
        while True:
            chunk = self.request.recv(1)
            if not chunk:
                break
            data += chunk
            if len(data) > MAX_LINE:
                return "__TOO_LONG__"
            if chunk == b"\n":
                break
        try:
            return data.decode("utf-8", errors="replace")
        except Exception:
            return "__DECODE_ERR__"

    def handle(self):
        start = time.time()
        wrong_total = 0  # for global penalty
        self.send(BANNER)
        self.send("Rules:\n")
        self.send("- Answers must be EXACT (copy/paste). No extra spaces.\n")
        self.send("- You get 3 wrong attempts with no cooldown.\n")
        self.send("- From the 4th wrong attempt: cooldown starts at 15s,\n")
        self.send("  then +10s for each next wrong attempt.\n")
        self.send("- Type answers, press Enter.\n\n")

        for idx, (q, expected) in enumerate(QUESTIONS, start=1):
            # session timeout guard
            if time.time() - start > TOTAL_TIMEOUT:
                self.send("\nSession timeout.\n")
                return

            while True:
                self.send(f"{q}\n> ")
                raw = self.recvline()

                if raw in ("__TOO_LONG__", "__DECODE_ERR__"):
                    wrong_total += 1
                    self.apply_cooldown(wrong_total)
                    self.send("Invalid input.\n\n")
                    continue

                ans = normalize_answer(raw)

                # basic input hygiene: require printable ASCII only
                if not ans or not ALLOWED_INPUT.match(ans):
                    wrong_total += 1
                    self.apply_cooldown(wrong_total)
                    self.send("Invalid input.\n\n")
                    continue

                # strict compare
                if safe_equal(ans, expected):
                    self.send("Correct.\n\n")
                    break
                else:
                    wrong_total += 1
                    self.apply_cooldown(wrong_total)
                    self.send("Wrong.\n\n")

        self.send("All answers correct!\n")
        self.send(f"FLAG: {FLAG}\n")
        self.send("Good luck!\n")

    def apply_cooldown(self, wrong_total: int) -> None:
        # 1-3 wrong attempts: no cooldown
        if wrong_total <= 3:
            return
        # 4th wrong: 15s, then +10s each next
        cooldown = 15 + (wrong_total - 4) * 10
        self.send(f"Cooldown: {cooldown} seconds...\n")
        time.sleep(cooldown)

class ThreadedTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    daemon_threads = True
    allow_reuse_address = True

if __name__ == "__main__":
    with ThreadedTCPServer((HOST, PORT), QuizHandler) as server:
        server.serve_forever()
